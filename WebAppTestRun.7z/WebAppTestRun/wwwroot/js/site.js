﻿// Please see documentation at https://docs.microsoft.com/aspnet/core/client-side/bundling-and-minification
// for details on configuring this project to bundle and minify static web assets.

// Write your Javascript code.

// Needed for upper tab selector
function openCity(evt, cityName) {
    var elements = document.getElementsByClassName('list');

    for (var i = 0; i < elements.length; i++) {
        elements[i].classList.remove('active');
    }

    var i, tabcontent, tablinks;
    tabcontent = document.getElementsByClassName("tabcontent");
    for (i = 0; i < tabcontent.length; i++) {
        tabcontent[i].style.display = "none";
    }
    tablinks = document.getElementsByClassName("tablinks");
    for (i = 0; i < tablinks.length; i++) {
        tablinks[i].className = tablinks[i].className.replace(" active", "");
    }
    document.getElementById(cityName).style.display = "block";
    evt.classList.add("active");
}


// Side Menu
function openSideTab(evt, tabName) {
    var elements = document.getElementsByClassName('tabList');

    for (var i = 0; i < elements.length; i++) {
        elements[i].classList.remove('active');
    }

    var i, tabcontent;
    tabcontent = document.getElementsByClassName("sideTabContent");
    for (i = 0; i < tabcontent.length; i++) {
        tabcontent[i].style.display = "none";
    }

    document.getElementById(tabName).style.display = "block";
    evt.classList.add("active");
}

// SecondSide Menu
function openSecondSideTab(evt, tabName) {
    var elements = document.getElementsByClassName('secondTabList');

    for (var i = 0; i < elements.length; i++) {
        elements[i].classList.remove('active');
    }

    var i, tabcontent;
    tabcontent = document.getElementsByClassName("secondSideTabContent");
    for (i = 0; i < tabcontent.length; i++) {
        tabcontent[i].style.display = "none";
    }
    
    document.getElementById(tabName).style.display = "block";
    evt.classList.add("active");
}


function updateValue(variableToChange, newValue) {

    $.ajax({
        type: 'GET',
        url: '/' + variableToChange + '/' + newValue,
        success: function (data, textStatus) {
            alert(data);
        },
        error: function (xhr, textStatus, errorThrown) {
            // Handle error
        }
    });



}