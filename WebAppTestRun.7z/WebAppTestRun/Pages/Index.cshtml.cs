﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebAppTestRun.Pages
{
	
	public class IndexModel : PageModel
    {
        private readonly ILogger<IndexModel> _logger;

        public IndexModel(ILogger<IndexModel> logger)
        {
            _logger = logger;
        }

    }

	public class ViewModelTest : PageModel
    {
        public ViewModelTest() { }
		public SelectList DropdownList { get; set; } = new SelectList(new List<string> { "This","is","a","test" });
        public string TestName { get; set; } = "";
        
	}

	[ApiController]
	[Route("Dev")]
	public class Dev : ControllerBase
	{
		[HttpGet("{baseVariable}/{newValue}")]
		public IActionResult TestOne(string baseVariable, string newValue)
		{

			return Ok();
		}


		public IActionResult Get()
		{

			return Ok();
		}

	}
}

